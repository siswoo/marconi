<?php
$nombreCompleto = "Juan Maldonado";
$aguinaldos = 0;
$ccss = 0;
$isr = 0;
$montoLaborado = 0;
$subTotal = 0;
$total = 0;

echo '
	<h2>Hola '.$nombreCompleto.'</h2>
	<p>Se ha generado su planilla digital con los siguientes detalles de pago.</p>
	<p>Aguinaldo: '.$aguinaldos.'</p>
	<p>ccss: '.$ccss.'</p>
	<p>isr: '.$isr.'</p>
	<p>Monto Laborado: '.$montoLaborado.'</p>
	<p>Sub-Total: '.$subTotal.'</p>
	<p>Total: '.$total.'</p>
	<h4>Para mas información o alguno inquietud comunicarse con gerencia</h4>
';
?>